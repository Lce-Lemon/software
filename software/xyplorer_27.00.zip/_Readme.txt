﻿
	Друзья. 
 Работа над проектом LRepacks ведётся ИСКЛЮЧИТЕЛЬНО благодаря материальной поддержке его пользователей.
 Без Вашей помощи создание репаков будет невозможным!

 Если для вас этот репак оказался полезен, внесите свой вклад в дальнейшую работу и развитие LRepacks любым доступным и удобным 
 способом на странице https://lrepacks.net/donate.html Полезной окажется ЛЮБАЯ, даже совсем незначительная на ваш взгляд, сумма.

 Поддержав проект, вы становитесь его Меценатом и получаете Premium доступ на сайте.
 Подробнее по сылке https://lrepacks.net/informaciya/206-podderzhka-proekta-i-poluchenie-premium-dostupa.html

 Помните, что даже просто загружая репаки со страниц LRepacks вы, пусть и немного, но тоже оказываете посильную помощь.
 В то время как загрузка репаков со сторонних ресурсов, не только подрывает его работу, но и может быть небезопасной для вас.


     							           		    			    Спасибо за понимание.


 ***********************************************************************************************************************************


	Friends.
 The work on the LRepacks project is carried out EXCLUSIVELY thanks to the financial support of its users.
 Creating repacks will be impossible without your help!

 If this repack was useful for you, please contribute to the further work and development of LRepacks in any available and 
 convenient way on page https://lrepacks.net/donate.html ANY amount even a very small one in your opinion will be useful.

 After your support of the project, you become its Patron and get Premium Access on site.
 More details on the link https://lrepacks.net/informaciya/206-podderzhka-proekta-i-poluchenie-premium-dostupa.html

 Remember that even just downloading repacks from the pages LRepacks you, even a little, but also render possible assistance.
 At the same time downloading repacks from the third-party resources not only undermines the site work but can also be unsafe for you.


     							           		    			Thank you for understanding.

